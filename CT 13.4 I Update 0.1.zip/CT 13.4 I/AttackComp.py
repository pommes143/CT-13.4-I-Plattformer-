import pygame

# 'class AttackComp():
#     pygame.display.set_mode((800, 700))
#     color = (200,200,100)'
    #pygame.draw.rect(win, color, pygame.Rect(self.x + 18, self.y + 8, 18, 30), 1)


if __name__ == '__main__':
    run = True
    while(run):
        (width, height) = (300, 200)
        screen = pygame.display.set_mode((width, height))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
##TEST nicht wichtig 
