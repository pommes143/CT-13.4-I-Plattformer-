import pygame
from Fenster import *
from Spieler import *

DerSpieler = Spieler(200, 500, 16, 16)
Spiel_Fenster = Fenster("spiel_fenster", 800, 700)

#####Sprite##########
#background = pygame.image.load()

class Steuerung():
    clock = pygame.time.Clock()
    run = True

    def __init__(self):
        #DerSpieler = Spieler(200, 500, 64, 64)
        self.schleife()

    def start(self):
        pygame.init()


    def redrawWindow(self):
        Spiel_Fenster.screen_name.fill((120,120,120))
        DerSpieler.draw(Spiel_Fenster.screen_name)
        pygame.display.update()

    def schleife(self):
        move = 3
        PlayHei = DerSpieler.height

        while self.run:
            self.clock.tick(30)
###################TASTEN##############################
            keys = pygame.key.get_pressed()
            if keys[pygame.K_a] and DerSpieler.x > 0:
                DerSpieler.posLeft = True
                DerSpieler.posRight = False
                DerSpieler.idle = False
                DerSpieler.x -= move
            elif keys[pygame.K_d] and DerSpieler.x < Spiel_Fenster.width - DerSpieler.width:
                DerSpieler.posLeft = False
                DerSpieler.posRight = True
                DerSpieler.idle = False
                DerSpieler.x += move
            else:
                DerSpieler.idle = True
                DerSpieler.wlkZaehler = 0
            if not DerSpieler.jmp: #Springen
                if keys[pygame.K_w]:
                    # DerSpieler.posLeft = False
                    # DerSpieler.posRight = False
                    DerSpieler.jmp = True
                    DerSpieler.wlkZaehler = 0
            else:
                if DerSpieler.jmpZaehler >= -5:
                    neg = 1
                    if DerSpieler.jmpZaehler < 0:
                        neg = -1
                    DerSpieler.y -= (DerSpieler.jmpZaehler ** 2) * 0.5 * neg
                    DerSpieler.jmpZaehler -= 1
                else:
                    DerSpieler.jmp = False
                    DerSpieler.jmpZaehler = 5

            if keys[pygame.K_s]:
                pass


            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.run = False
                # if event.type == pygame.KEYDOWN:
                #     if event.key == pygame.K_s:
                #         pass
                #         DerSpieler.height = DerSpieler.height/2
                # if event.type == pygame.KEYUP:
                #     if event.key == pygame.K_a:
                #         pass
                #     if event.key == pygame.K_d:
                #         pass
                #     if event.key == pygame.K_s:
                #         pass
                #         DerSpieler.height = PlayHei
                #     if event.key == pygame.K_w:
                #         pass

            self.redrawWindow()

        pygame.quit()
