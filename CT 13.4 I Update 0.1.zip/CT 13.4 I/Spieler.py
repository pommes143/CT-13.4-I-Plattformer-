import pygame
class Spieler(object):
    """docstring for Spieler."""
    stamina = 0
    strengh = 0
    agility = 0
    luck = 0
    charisma = 0
    mana = 0
    #############
    x = 0
    y = 0
    width = 0
    height = 0
    color = (102,200,5)
    #############
    posRight = False
    posLeft = False
    idle = True
    jmp = False;
    jmpZaehler = 5
    ##############
    wRight = [pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-00.png"),pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-01.png"),pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-02.png"), pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-03.png"), pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-04.png"), pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-05.png")]
    wLeft = [pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-00.png"),pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-01.png"),pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-02.png"), pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-03.png"), pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-04.png"), pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-05.png")]


    def __init__(self, x, y, width, height):
        super(Spieler, self).__init__()
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def getX():
        return self.x
    def getY():
        return self.y
    def getWidth():
        return self.width
    def getHeight():
        return self.height

    def draw(self, s):

        if self.wlkZaehler + 1 >= 30:
            self.wlkZaehler = 0

        if not(self.idle):
            if self.posRight:
                s.blit(self.wRight[self.wlkZaehler//6], (self.x, self.y))
                self.wlkZaehler += 1

            elif self.posLeft:
                s.blit(self.wLeft[self.wlkZaehler//6], (self.x, self.y))
                self.wlkZaehler += 1

        else:
            if self.posRight:
                s.blit(self.wRight[0], (self.x, self.y))
            else:
                s.blit(self.wLeft[0], (self.x, self.y))

        #s.blit(pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-idle-00.png"), (self.x, self.y))

        #s.blit(pygame.image.load("/home/barnable/Desktop/Informatik/CT 13.4 I/images/Individual_Sprites/adventurer-run-00.png"), (self.x,self.y))
        pygame.draw.rect(s, self.color, pygame.Rect(self.x + 18, self.y + 8, 18, 30), 1)
