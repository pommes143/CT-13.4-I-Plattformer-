import pygame
from Steuerung import *
#DieSteuerung = Steuerung

if __name__ == '__main__':
    DieSteuerung = Steuerung()
    DieSteuerung.start()
